class MerchShop:  
    def __init__(self):  # Правильное имя метода конструктора
        self.goods = []  # Инициализация пустого списка
        self.customers = []
        self.orders = []
          
    def add_good(self, good):  # Параметр 'good', а не 'goods'
        self.goods.append(good)
          
    def register_customer(self, customer):  # Метод и параметр поправлены
        self.customers.append(customer)
          
    def process_order(self, order):
        # Логика обработки заказа  
        pass
  
class Good:  
    def __init__(self, productcode, nameofgood, author):  # Правильное имя конструктора
        self.productcode = productcode  
        self.nameofgood = nameofgood  # Имя переменной с маленькой буквы для стиля
        self.author = author  
        self.available = True  
  
class Customer:  
    def __init__(self, customer_id, name):  # Правильный конструктор
        self.customer_id = customer_id  # исправлено с reader_id на customer_id
        self.name = name  
        self.buyed_goods = []  # Инициализация пустого списка
          
    def buy_goods(self, good):  
        if good.available:  
            self.buyed_goods.append(good)  
            good.available = False  
  
# Пример создания объектов  
merchshop = MerchShop()  
good1 = Good("12345", "Чехол", "Aurum")  
customer1 = Customer(1, "Иванов Иван")  
  
merchshop.add_good(good1)  # Исправлено с add_book на add_good  
merchshop.register_customer(customer1)  # Исправлено с register_reader на register_customer  
customer1.buy_goods(good1)  # Исправлено с book1 на good1 
