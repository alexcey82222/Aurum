<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require "PHPMailer/src/Exception.php";
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

header("Content-Type: application/json");

// Получаем и декодируем JSON-данные
$data = json_decode(file_get_contents("php://input"), true);

// Проверка на наличие товаров в корзине
if (empty($data["products"])) {
    echo json_encode(["status" => "error", "message" => "Корзина пуста!"]);
    exit;
}

// Очищаем входные данные от XSS атак
function clean($value) {
    return htmlspecialchars(strip_tags(trim($value)));
}

// Формирование таблицы товаров
$productsHTML = "";
$totalCost = clean(number_format($data["totalCost"], 0, ',', ' ')) . " ₽";
$totalCostWithoutDiscount = clean(number_format($data["totalCostWithoutDiscount"], 0, ',', ' ')) . " ₽";
$customerName = clean($data["customerName"]);
$customerPhone = clean($data["customerPhone"]);

foreach ($data["products"] as $product) {
    $name = clean($product["name"]);
    $price = clean(number_format($product["price"], 0, ',', ' ')) . " ₽";
    $priceDiscount = clean(number_format($product["priceDiscount"], 0, ',', ' ')) . " ₽";

    $productsHTML .= "
        <tr>
            <td style='padding: 10px; border-bottom: 1px solid #e5e5e5; font-size: 14px; text-align: left;'>$name</td>
            <td style='padding: 10px; border-bottom: 1px solid #e5e5e5; font-size: 14px; text-align: left;'><strong>$price</strong></td>
            <td style='padding: 10px; border-bottom: 1px solid #e5e5e5; color: #d9534f; font-size: 14px; text-align: left;'><strong>$priceDiscount</strong></td>
        </tr>
    ";
}

// Тело письма в формате HTML
$emailBody = "
<html>
<head>
    <title>Новый заказ с сайта</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; margin: 0; padding: 0; width: 100%; display: flex; justify-content: center; }
        .container { width: 100%; max-width: 1000px; margin: 20px; background-color: #ffffff; }
        table { width: 100%; border-collapse: collapse; }
        .total { font-size: 16px; color: #555; }
        .without-discount { font-size: 16px; font-weight: 600; color: #888; text-decoration: line-through; }
        .section-title { font-size: 20px; font-weight: 700; color: #444; margin-top: 30px; }
        .contact-info p { font-size: 16px; color: #555; }
        h4 { margin-top: 50px; margin-bottom: 25px; }
    </style>
</head>
<body>
    <div class='container'>
        <h4>Детали заказа</h4>
        <table>
            <thead>
                <tr>
                    <th style='text-align: left;'><strong>Товар</strong></th>
                    <th style='text-align: left;'><strong>Цена</strong></th>
                    <th style='text-align: left;'><strong>Цена со скидкой</strong></th>
                </tr>
            </thead>
            <tbody>
                $productsHTML
            </tbody>
        </table>

        <h4>Сумма заказа</h4>
        <div class='total'>
            <p>Итого без скидки: $totalCostWithoutDiscount</p>
            <p>Итого со скидкой: $totalCost</p>
        </div>

        <h4>Контактные данные</h4>
        <div class='contact-info'>
            <p>Имя: $customerName</p>
            <p>Телефон: $customerPhone</p>
        </div>
    </div>
</body>
</html>
";

// Настройка и отправка письма
$mail = new PHPMailer(true);

try {
    // Настройки SMTP
    $mail->isSMTP();
    $mail->Host = 'smtp.timeweb.ru';
    $mail->SMTPAuth = true;
    $mail->Username = 'admin@shopping-cart.webtm.ru'; // Ваш email
    $mail->Password = '0281f25DD'; // Ваш пароль
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 2525;
    $mail->CharSet = 'UTF-8';

    // Адрес отправителя и получателя
    $mail->setFrom('admin@shopping-cart.webtm.ru', 'Интернет-магазин');
    $mail->addAddress('admin@toxakoleso.tw1.ru', 'Получатель');

    // Тема и содержимое письма
    $mail->isHTML(true);
    $mail->Subject = 'Новый заказ с сайта';
    $mail->Body = $emailBody;
    $mail->AltBody = 'Общая сумма со скидкой: ' . $totalCost;

    // Отправка письма
    $mail->send();
    echo json_encode(["status" => "success", "message" => "Заказ успешно отправлен!"]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $mail->ErrorInfo]);
}
?>
